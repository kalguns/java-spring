create function get_department_count_by_name(dep_name character varying) returns integer
    language plpgsql
as
$$
declare
    department_count integer;
begin
    select count(*)
    into department_count
    from employees
    where department=dep_name;

    return department_count;
end;
$$;

alter function get_department_count_by_name(varchar) owner to postgres;

